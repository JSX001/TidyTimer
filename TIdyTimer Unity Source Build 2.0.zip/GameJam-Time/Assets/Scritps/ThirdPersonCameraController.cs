﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ThirdPersonCameraController : MonoBehaviour
{
       public Transform toLookat;

    public float xOffset = 0f;
    public float zOffset = 0f;
    public float yOffset = 0f;

    void Start()
    {
        xOffset = toLookat.position.x - transform.position.x;
        zOffset = toLookat.position.z - transform.position.z;
        yOffset = toLookat.position.y - transform.position.y;
    }


    private void LateUpdate() 
    {
        Vector3 pos = toLookat.position;
        pos.z -= zOffset;
        pos.x -= xOffset;
        pos.y -= yOffset;

        transform.position = pos;
        transform.LookAt(toLookat);
    }
}
