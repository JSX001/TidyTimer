﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent( typeof(MeshFilter))]
public class UsedTimeMesh : MonoBehaviour
{
    public float height = 40;
    public ClockController clockController;
    Mesh mesh;
    public float degsOffset = 0;

    public Vector3[] vertices;
    public int[] triangles;
    public Vector2[] uv;

    void Awake()
    {
        mesh = GetComponent<MeshFilter>().mesh;
    }

    void Start()
    {
        vertices = new Vector3[60*3];
        triangles = new int[60 * 3];
        uv = new Vector2[60 *3];
    }

    void Update()
    {
        makeMesh();
        createMesh();

        // do not create a collider if no vertices!
        if ( clockController.seconds < 1)
            return;

        var collider = GetComponent<MeshCollider>();
        if ( collider != null)
            Destroy( collider);

        collider = this.gameObject.AddComponent<MeshCollider>();
        collider.convex = false;
    }

    void makeMesh()
    {
        float seconds = clockController.seconds;

        if ( seconds > 60)
            seconds = 60;
        if ( clockController.minutes > 0)
            seconds = 60;
        
        for( int i = 0; i < (int) seconds; i++)
        {
            vertices[i*3] =  new Vector3( 0,0,0);
            vertices[i*3+1] = PointOnCircle( height, i *6, new Vector3(0,0,0) );
            vertices[i*3+2] = PointOnCircle( height, (i+1)*6 , new Vector3(0,0,0) );

            uv[i*3] = new Vector2( vertices[i*3].x, vertices[i*3].z);
            uv[i*3+1] = new Vector2( vertices[i*3+1].x, vertices[i*3+1].z);
            uv[i*3+2] = new Vector2( vertices[i*3+2].x, vertices[i*3+2].z);
            
            triangles[i*3] = i*3;
            triangles[i*3+1] = i*3 + 1;
            triangles[i*3+2] = i*3 + 2;
        }
    }

    void createMesh()
    {
        mesh.Clear();
        mesh.vertices = vertices;
        mesh.triangles = triangles;
        mesh.uv = uv;
        mesh.RecalculateNormals();
    }

    public Vector3 PointOnCircle(float radius, float angleInDegrees, Vector3 origin)
    {
        // Convert from degrees to radians via multiplication by PI/180        
        float x = (float)(radius * Mathf.Cos(angleInDegrees * Mathf.PI / 180F)) + origin.x;
        float z = (float)(radius * Mathf.Sin(angleInDegrees * Mathf.PI / 180F)) + origin.z;

        return new Vector3(z, 0, x);
    }
}
