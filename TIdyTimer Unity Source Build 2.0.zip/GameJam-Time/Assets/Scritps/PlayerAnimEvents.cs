﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimEvents : MonoBehaviour
{
    // event added in animation track.
    public static event Action<int> pickupAnimCompleted = delegate {};
    

    public void PickupAnimCompletedEvent(string s) 
    {
        pickupAnimCompleted(0);
    }


}
