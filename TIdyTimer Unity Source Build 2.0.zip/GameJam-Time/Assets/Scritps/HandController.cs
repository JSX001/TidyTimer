﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HandController : MonoBehaviour
{
    public float force = 2f;


    void FixedUpdate()
    {
    }

    void OnCollisionEnter(Collision other)
    {
        if ( other.gameObject.tag.Equals("Treasure"))
        {
            var t = other.gameObject.GetComponent<Treasure>();
            if ( t != null)
            {
                t.Die();
                other.gameObject.GetComponent<Rigidbody>().AddForce(transform.rotation.eulerAngles * force, ForceMode.Impulse);
            }
            
        }
    }
}
