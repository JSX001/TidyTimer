﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ThirdPersonCharacterController : MonoBehaviour
{
    public float Speed;
    public Transform playerModel;
    public Animator playerAnimator;
    public bool isWalking = false;
    public bool isPickingUp = false;
    public bool isHolding = false;
    public bool isDying = false;

    bool playerIsPaused = false;
    Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();    
        playerAnimator = playerModel.GetComponent<Animator>();
        isDying = false;
        isPickingUp = false;
        isHolding = false;
        isWalking = false;
    }


    void FixedUpdate()
    {
        if ( !isDying && !playerIsPaused)
            PlayerMovement();
    }

    public void setAnimFlags()
    {
        playerAnimator.SetBool("isWalking", isWalking);
        playerAnimator.SetBool("isHolding", isHolding);

    }

    void PlayerMovement()
    {
        float hor = Input.GetAxis("Horizontal");
        float ver = Input.GetAxis("Vertical");


        Vector3 playerMovement = new Vector3( hor, 0f, ver) * Speed * Time.deltaTime;

        if ( isPickingUp)
            playerMovement = Vector3.zero;

        if ( playerMovement != Vector3.zero)
        {
            isWalking = true;
            playerModel.transform.rotation = Quaternion.LookRotation(playerMovement);
            rb.velocity = playerMovement;
        }
        else{
            isWalking = false;
        }

        setAnimFlags();
    }

    void OnCollisionEnter(Collision other)
    {
        if ( isDying)
            return;
        if ( other.gameObject.tag.Equals("Enemy"))
        {
            StartCoroutine("playDeathAnim");
        }
    }

    IEnumerator playDeathAnim()
    {
        isDying = true;
        rb.constraints = RigidbodyConstraints.None;
        rb.AddForce( Vector3.up * 6f + Vector3.forward * 2f, ForceMode.Impulse);
        playerAnimator.SetTrigger("Death");
        yield return new WaitForSeconds(3f);
        
        GameController._playerJustDied = true;
    }

    public void startPickupAnim()
    {
        isPickingUp = true;
        playerAnimator.SetTrigger("pickUp");
    }

    public void pausePlayer()
    {
        stopPlayer();
        playerIsPaused = true;
    }

    public void stopPlayer()
    {
        this.isDying = false;
        this.isWalking = false;
        this.isPickingUp = false;
        this.setAnimFlags();
        this.rb.velocity = Vector3.zero;
    }
}
