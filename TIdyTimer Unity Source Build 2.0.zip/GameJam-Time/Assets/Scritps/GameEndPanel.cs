﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameEndPanel : MonoBehaviour
{
    [SerializeField] Text title;
    [SerializeField] Text detail1;
    [SerializeField] Text detail2;

    bool waitingForInstruction = false;

    void Start()
    {
        this.gameObject.SetActive(false);
    }

    public void showPanel(bool success, string msg)
    {
        if ( success)
        {
            title.text = "Congratulations you have won";
            detail1.text = msg;
            detail2.text = "Press any key to move to level " + GameController.getNextLevel();
        }
        else
        {
            title.text = "Bad Luck, you have failed in your quest";
            detail1.text = msg;
            detail2.text = "Press any key to return to title screen, or R to restart this level ";
        }
        
        waitingForInstruction = true;
        gameObject.SetActive(true);
        GameController.setUIPause(2f);

    }

   

}
