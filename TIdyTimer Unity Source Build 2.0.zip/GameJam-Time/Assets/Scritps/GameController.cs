﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    public enum GAME_MODE { STOPPED, RUNNING };

    [SerializeField] AudioSource clockSound;
    [SerializeField] AudioSource gameMusic;
    [SerializeField] ClockController clockController;
    [SerializeField] ThirdPersonCharacterController playerController;

    [SerializeField] GameEndPanel gameEndPanel;
    [SerializeField] InGameUIPanel inGamePanel;

    public float TimeToPlayTune = 3f;

    public static int _blockCount = 0;
    public static int _deadBlocks = 0;
    public static bool _introScreenOn = true;
    public static bool _playerJustDied = false;
 
    const int LAST_LEVEL = 9;

    private static int _currentLevel = 0;
    private static bool _gameWon = false;
    private static float _uiPause = 0f;

    private static ClockController _clockController;
    private static GameController _gameController; 

    private static List<Treasure> _blockList;

    private int safeBlocks = 0;

    private static GAME_MODE _gameMode;


    void Awake()
    {
        _gameController = this;
        _blockList = new List<Treasure>();
        _gameMode = GAME_MODE.STOPPED;
    }

    void Start()
    {
        if ( _currentLevel > 0)
            startLevel();
    }

    public static bool isDebugMode()
    {
        return true;
    }

    void Update()
    {
        if ( Input.GetKey( KeyCode.Escape) )
        {
            SceneManager.LoadScene(0);
        }

        switch( _gameMode)
        {
            case GAME_MODE.STOPPED:
                stoppedUpdate();
                break;

            case GAME_MODE.RUNNING:
                runningUpdate();
                break;

            default:
                break;
        }

    }

    void runningUpdate()
    {
        checkLevelChanger();
        if ( Input.GetKey(KeyCode.R) )
        {
            SceneManager.LoadScene(_currentLevel);
        }

        safeBlocks = 0;
        foreach( var block in _blockList)
        {
            if ( block.isSafe)
                safeBlocks++;
        }

        if ( clockController.minutes > 1)
        {
            // out of time
            gameLost(false);
        }
        else if (  _blockCount == 0 || _playerJustDied)
        {
            // no more blocks left or player died
            gameLost(_playerJustDied);
            return;
        }
        else if ( safeBlocks == _blockCount)
        {
            // all the blocks on screen are sage, did we save enough
            gameWon();
            updateRunningGameUI();
            return;
        }
        

        if ( !gameMusic.isPlaying &&  clockController.seconds >= TimeToPlayTune)
        {
            gameMusic.Play();
        }
        
        updateRunningGameUI();
    }

    void stoppedUpdate()
    {
        // game is in stopped mode, no character movement
        // all sound off

        if ( _uiPause > 0)
        {
            _uiPause -= Time.deltaTime;
            return;
        }


         if ( Input.GetKey(KeyCode.R) )
        {
            SceneManager.LoadScene(_currentLevel);
        }
        else if ( Input.anyKey)
        {
            if ( _gameWon)
            {
                moveToNextLevel();
                return;
            }

            _currentLevel = 0;
            SceneManager.LoadScene(_currentLevel);
        }
    }

    void checkLevelChanger()
    {
        if ( !isDebugMode() )
            return;
            
        if ( Input.GetKey( KeyCode.Alpha1))
        {
            _currentLevel = 1;
            SceneManager.LoadScene(_currentLevel);
        }
        else if ( Input.GetKey( KeyCode.Alpha2) )
        {
            _currentLevel = 2;
            SceneManager.LoadScene(_currentLevel);
        }
        else if ( Input.GetKey( KeyCode.Alpha3) )
        {
            _currentLevel = 3;
            SceneManager.LoadScene(_currentLevel);
        }
        else if ( Input.GetKey( KeyCode.Alpha4) )
        {
            _currentLevel = 4;
            SceneManager.LoadScene(_currentLevel);
        }
        else if ( Input.GetKey( KeyCode.Alpha5) )
        {
            _currentLevel = 5;
            SceneManager.LoadScene(_currentLevel);
        }
        else if ( Input.GetKey( KeyCode.Alpha6) )
        {
            _currentLevel = 6;
            SceneManager.LoadScene(_currentLevel);
        }
        else if ( Input.GetKey( KeyCode.Alpha7) )
        {
            _currentLevel = 7;
            SceneManager.LoadScene(_currentLevel);
        }
        else if ( Input.GetKey( KeyCode.Alpha8) )
        {
            _currentLevel = 8;
            SceneManager.LoadScene(_currentLevel);
        }
        else if ( Input.GetKey( KeyCode.Alpha9) )
        {
            _currentLevel = 9;
            SceneManager.LoadScene(_currentLevel);
        }
    }


    void updateRunningGameUI()
    {
        int s = 60 - clockController.seconds;
        if ( clockController.minutes > 0)
            s = 0;

        inGamePanel.setSeconds(s);
        inGamePanel.setScore("safe toys: " + safeBlocks);
    }
    
    public static int getNextLevel()
    {
        return _currentLevel >= LAST_LEVEL ? 1 : _currentLevel+1;
    }

    public static void moveToNextLevel()
    {
        _currentLevel++;
        if ( _currentLevel > LAST_LEVEL )
        {
            _currentLevel = 0;
        }
        SceneManager.LoadScene( _currentLevel);
    }

    public static void resetLevels()
    {
        _currentLevel = 1;
    }

    public static void registerBlock( Treasure block)
    {
        _blockList.Add( block);
        _blockCount = _blockList.Count;
    }

    public static void loseBlock()
    {
        _deadBlocks++;
        _blockCount--;
        _gameController.gameLost(false);
    }

    public static bool isGameRunning()
    {
        return _gameMode == GAME_MODE.RUNNING;
    }

    public void startLevel()
    {
        _deadBlocks = 0;
        _gameMode = GAME_MODE.RUNNING;
        _playerJustDied = false;
        clockSound.Play();
    }

    public void gameLost(bool didPlayerDie)
    {
        _gameWon = false;
        _gameMode = GAME_MODE.STOPPED;

        playerController.pausePlayer();
        _gameController.stopAllSound();

        gameEndPanel.showPanel( false, didPlayerDie ? "You got caught by time!" :  "You lost too many toys");
        inGamePanel.hideInstructions();
    }

    public void  gameWon()
    {
        _gameWon = true;
        _gameMode = GAME_MODE.STOPPED;

        playerController.pausePlayer();
        _gameController.stopAllSound();

        gameEndPanel.showPanel( true, "You saved " + safeBlocks + " toys in " + clockController.seconds + " seconds");
        inGamePanel.hideInstructions();
    }

    void stopAllSound()
    {
        clockSound.Stop();
        gameMusic.Stop();
    }

    public static void setUIPause(float seconds)
    {
        _uiPause = seconds;
    }

}
