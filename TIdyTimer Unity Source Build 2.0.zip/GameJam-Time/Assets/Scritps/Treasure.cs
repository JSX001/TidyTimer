﻿using UnityEngine;

public class Treasure : MonoBehaviour
{
    public GameObject explosion;
    public float deathTimeout = -100f;

    public bool isDead = false;
    GameObject deathParticle;
    public bool isSafe = false;

    public float raySize = 1f;
    public float rayYoffset = 0f;

    void Start()
    {
        GameController.registerBlock(this);
    }

    void Update()
    {
        Vector3 pos = new Vector3( transform.position.x, transform.position.y + rayYoffset, transform.position.z);
        Ray ray = new Ray( pos, Vector3.down);
        Debug.DrawRay(ray.origin, ray.direction * raySize, Color.red);
        RaycastHit hit;

        isSafe = false;
        if ( Physics.Raycast( ray, out hit, raySize) )
        {
            
            if ( hit.transform.tag == "SafeZone")
            {
                isSafe = true;
            }
        }


        if ( deathTimeout <= -100)
            return;
        
        deathTimeout-= Time.deltaTime;
        if ( deathParticle != null)
        {
            deathParticle.transform.position = transform.position;
            deathParticle.transform.rotation = transform.rotation;
        }

        if ( deathTimeout <=0)
        {
            Destroy(this.gameObject);
        }
    }

    public void Die()
    {
        if ( isDead)
            return;

        GameController.loseBlock();
        if ( explosion != null)
        {
            deathParticle = Instantiate( explosion, transform.position, Quaternion.identity);
        }
        deathTimeout=  1f;
        isDead = true;

    }


}
