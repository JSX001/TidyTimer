﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InGameUIPanel : MonoBehaviour
{
    [SerializeField] Text secondsText;
    [SerializeField] Text ScoreText;
    [SerializeField] Text instructionsText;

    private string[] instructions = {
        "",
        "Move the toy block to the safe zone \n (be careful how you throw!)",
        "You could throw toys over the hand to save them!"
    };

    public void hideInstructions()
    {
        this.instructionsText.text = "";
    }

    public void setInstructions(int level)
    {
        if ( instructions[level].Length == 0)
        {
            this.gameObject.SetActive(false);
        }
        else
        {
            this.gameObject.SetActive(true);
            instructionsText.text = instructions[level];
        }
    }

    public void setSeconds(int seconds)
    {
        this.secondsText.text = seconds.ToString();
    }

    public void setScore( string scoreText)
    {
        this.ScoreText.text = scoreText;
    }

}
