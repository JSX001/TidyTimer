﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ArmController : MonoBehaviour
{
    // handles the player holding and releasing items

    public Treasure holdingTreasure = null;

    public float forwardThrowForce = 2f;
    public float upThrowForce = 10f;
    public Transform handle;
    public Transform rayOrigin;
    public LayerMask treasureLayer;
    public float pickupLength = 3f;
    public float sphereRadius = 1f;

    ThirdPersonCharacterController controller;
    Rigidbody playerRigidBody;

    float noActionTimeout = 0f;
    private const float NO_ACTION_TIME = 0.5f;
    private bool pickingUp = false;

    private void Awake() 
    {
        PlayerAnimEvents.pickupAnimCompleted += pickupAnimCompleted;
    }

    void OnDestroy()
    {
        PlayerAnimEvents.pickupAnimCompleted -= pickupAnimCompleted;
    }

    void Start()
    {
        playerRigidBody = GameObject.Find("Player").GetComponent<Rigidbody>();
        controller = GetComponent<ThirdPersonCharacterController>();
        pickingUp = false;
    }


    void Update()
    {
        if ( !GameController.isGameRunning() )
            return;

        if ( controller.isDying)
        {
            if ( holdingTreasure != null)
                doThrow();
            return;
        }

        if ( noActionTimeout > 0)
        {
            // waiting time before we can pick up again, also
            // wait until the treasure has been thrown out of range of our players colliders
            // so we don't get bonkers movement.

            noActionTimeout -= Time.deltaTime;

            if ( noActionTimeout <= 0)
            {
                // switch colliders back on now the object is far enough away
                Physics.IgnoreCollision(holdingTreasure.GetComponent<Collider>(), this.GetComponent<Collider>(), false);
                holdingTreasure = null;
            }
        }
        else if ( Input.GetButton("Jump") || Input.GetMouseButtonDown(0) ) 
        {
            if ( holdingTreasure == null)
                startPickup();
            else
                doThrow();
        }
    }


    Vector3 pickupPoint = Vector3.zero;

    Vector3 rayOriginVector = Vector3.zero;
    Vector3 rayDirectionVector  = Vector3.zero;
    float hitDistance = 0f;

    void startPickup() 
    {
        RaycastHit hit;
        Ray ray = new Ray( rayOrigin.position, handle.forward);


        // if ( Physics.Raycast( ray, out hit, pickupLength) )
        if ( Physics.SphereCast( ray.origin, sphereRadius, ray.direction, out hit, pickupLength) )
        {
            rayOriginVector = ray.origin;
            rayDirectionVector = ray.direction;
            hitDistance = hit.distance;

            pickupPoint = hit.point;
            Debug.DrawLine( ray.origin, pickupPoint, Color.yellow);
            this.holdingTreasure = hit.collider.gameObject.GetComponent<Treasure>();
            controller.startPickupAnim();
            pickingUp = true;
        }
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawLine( rayOriginVector, rayOriginVector + rayDirectionVector * hitDistance);
        Gizmos.DrawWireSphere(rayOriginVector + rayDirectionVector  * hitDistance, sphereRadius);
    }


    void pickupAnimCompleted(int i)
    {
        completePickup();
    }

    float pickupMass = 0f;
    
    void completePickup()
    {
        Physics.IgnoreCollision(holdingTreasure.GetComponent<Collider>(), this.GetComponent<Collider>());

        var treasureRigidBody = holdingTreasure.GetComponent<Rigidbody>();
        pickupMass = treasureRigidBody.mass;
        Destroy(treasureRigidBody);

        var distance = Vector3.Distance( handle.transform.position, pickupPoint);

        Vector3 newPos = (handle.position - pickupPoint).normalized * distance;
        holdingTreasure.transform.position += newPos;

        holdingTreasure.transform.parent = this.handle.transform;
        controller.isPickingUp = false;
        controller.isHolding = holdingTreasure != null;
        controller.setAnimFlags();
        pickingUp = false;
    }


    void doThrow()
    {
        if ( holdingTreasure == null || pickingUp) 
            return;

        var treasureRigidBody = holdingTreasure.GetComponent<Rigidbody>();
        if ( treasureRigidBody == null)
        {
             treasureRigidBody = holdingTreasure.gameObject.AddComponent<Rigidbody>();
        }
        treasureRigidBody.mass = pickupMass;
        treasureRigidBody.isKinematic = false;
        treasureRigidBody.useGravity = true;
    
        holdingTreasure.transform.parent = null;

        Vector3 forceTransform = handle.transform.forward * forwardThrowForce;
        forceTransform += transform.up * upThrowForce;

        if ( !controller.isDying)
            treasureRigidBody.AddForce( forceTransform, ForceMode.Impulse);

        noActionTimeout = NO_ACTION_TIME;
        controller.isHolding = false;
        controller.setAnimFlags();

    }
   
}
