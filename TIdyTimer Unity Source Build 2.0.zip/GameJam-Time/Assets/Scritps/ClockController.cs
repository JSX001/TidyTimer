﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ClockController : MonoBehaviour
{
    
    public Transform secondHand;
    public Transform pivot;

    public float secondsF = 0;
    public int seconds = 0;
    public int minutes = 0;
    
    bool stopTheClock = false;

    Rigidbody rb;

    void Start()
    {
        rb = secondHand.GetComponent<Rigidbody>();
        Quaternion rot = Quaternion.Euler( 0f, seconds * 6, 0f);
        secondHand.GetComponent<Rigidbody>();

        rb.MoveRotation( rot);
    }

    void Update()
    {
        if( Input.GetKey( KeyCode.T) )
        {
            this.stopTheClock = !this.stopTheClock;
        }
    }
    
    void FixedUpdate()
    {
        if ( !GameController.isGameRunning() || this.stopTheClock)
            return;

        secondsF = secondsF + Time.deltaTime;
        seconds =  (int) secondsF;
        if ( seconds > 59)
        {
            secondsF = 0;
            seconds = 0;
            minutes++;
        }

        Quaternion rot = Quaternion.Euler( 0f, seconds * 6, 0f);
        secondHand.GetComponent<Rigidbody>();

        rb.MoveRotation( rot);
    }


    public void resetClock()
    {
        seconds = 0;
        secondsF = 0;
        minutes = 0;
    }
}
