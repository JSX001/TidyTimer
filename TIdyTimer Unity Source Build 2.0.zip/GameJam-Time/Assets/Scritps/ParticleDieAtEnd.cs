﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParticleDieAtEnd : MonoBehaviour
{
    float timeout = 3f;

    void Update()
    {
        timeout -= Time.deltaTime;
        if ( timeout <= 0)
            Destroy(this.gameObject);
    }
}
